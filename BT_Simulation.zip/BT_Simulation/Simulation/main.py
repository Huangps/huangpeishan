import sys
sys.path.insert(0, 'bt/')
from vrep_api import *
from BTSearchActionNodes import *
from BTSearchConditionNodes import *
# from NewDraw import new_draw_tree
from SequenceNode import SequenceNode
from FallbackNode import FallbackNode


def AchieveGoal():

    vrep = vrep_api()
    print('connection successed!!')

    green_cube_id = vrep.get_id(b'greenCube')
    goal_id = vrep.get_id(b'goalLocation')

    # move_to_cube_subtree
    # ? IsRobotClosetoGreenCube
    #   MoveToGreenCube
    move_to_cube_subtree = FallbackNode('Fallback')
    is_robot_close_to_green_cube = IsRobotCloseTo('IsRobotClosetoGreenCube', green_cube_id, vrep)
    move_to_green_cube = MoveCloseTo('MoveToGreenCube', green_cube_id, vrep)
    move_to_cube_subtree.AddChild(is_robot_close_to_green_cube)
    move_to_cube_subtree.AddChild(move_to_green_cube)

    # grasp_cube_sequence
    # -> (? IsRobotClosetoGreenCube
    #       MoveToGreenCube)
    #    GraspGreenCube
    grasp_cube_sequence = SequenceNode('GraspCubeSequence')
    grasp_green_cube = GraspObject('GraspGreenCube', green_cube_id, vrep)
    grasp_cube_sequence.AddChild(move_to_cube_subtree)
    grasp_cube_sequence.AddChild(grasp_green_cube)

    # grasp_cube_subtree
    # ? IsGreenCubeGrasped
    #   (-> (? IsRobotClosetoGreenCube
    #          MoveToGreenCube)
    #       GraspGreenCube)
    grasp_cube_subtree = FallbackNode('Fallback')
    is_green_cube_grasped = IsObjectGrasped('IsGreenCubeGrasped', green_cube_id, vrep)
    grasp_cube_subtree.AddChild(is_green_cube_grasped)
    grasp_cube_subtree.AddChild(grasp_cube_sequence)

    # move_to_goal_subtree
    # ? IsRobotClosetoGoal
    #   MoveToGoal
    move_to_goal_subtree = FallbackNode('Fallback')
    is_robot_close_to_goal = IsRobotCloseTo('IsRobotClosetoGoal', goal_id, vrep)
    move_to_goal = MoveCloseTo('MoveToGoal', goal_id, vrep)
    move_to_goal_subtree.AddChild(is_robot_close_to_goal)
    move_to_goal_subtree.AddChild(move_to_goal)

    # place_green_cube_sequence
    # -> (? IsGreenCubeGrasped
    #       (-> (? IsRobotClosetoGreenCube
    #               MoveToGreenCube)
    #           GraspGreenCube))
    #    (? IsRobotClosetoGoal
    #       MoveToGoal)
    #    DropGreenCube
    place_green_cube_sequence = SequenceNode('PlaceGreenCube')
    place_green_cube = DropObject('DropGreenCube', vrep)
    place_green_cube_sequence.AddChild(grasp_cube_subtree)
    place_green_cube_sequence.AddChild(move_to_goal_subtree)
    place_green_cube_sequence.AddChild(place_green_cube)

    # root
    # ? IsGreenAtGoal
    #   (-> (? IsGreenCubeGrasped
    #          (-> (? IsRobotClosetoGreenCube
    #                 MoveToGreenCube)
    #              GraspGreenCube))
    #       (? IsRobotClosetoGoal
    #          MoveToGoal)
    #       DropGreenCube)
    root = FallbackNode('root')
    is_green_cube_at = IsObjectAt('IsGreenAtGoal', green_cube_id, goal_id, vrep)
    root.AddChild(is_green_cube_at)
    root.AddChild(place_green_cube_sequence)

    # draw_thread = threading.Thread(target=new_draw_tree, args=(root,))
    # draw_thread.start()
    while True:
        root.Execute(None)
        time.sleep(1)


def Pickup():

    vrep = vrep_api()
    print('connection successed!!')

    green_cube_id = vrep.get_id(b'greenCube')

    # move_to_cube_subtree
    # ? IsRobotClosetoGreenCube
    #   MoveToGreenCube
    move_to_cube_subtree = FallbackNode('Fallback')
    is_robot_close_to_green_cube = IsRobotCloseTo('IsRobotClosetoGreenCube', green_cube_id, vrep)
    move_to_green_cube = MoveCloseTo('MoveToGreenCube', green_cube_id, vrep)
    move_to_cube_subtree.AddChild(is_robot_close_to_green_cube)
    move_to_cube_subtree.AddChild(move_to_green_cube)

    # grasp_cube_sequence
    # -> (? IsRobotClosetoGreenCube
    #       MoveToGreenCube)
    #    GraspGreenCube
    grasp_cube_sequence = SequenceNode('GraspCubeSequence')
    grasp_green_cube = GraspObject('GraspGreenCube', green_cube_id, vrep)
    grasp_cube_sequence.AddChild(move_to_cube_subtree)
    grasp_cube_sequence.AddChild(grasp_green_cube)

    # grasp_cube_subtree
    # ? IsGreenCubeGrasped
    #   (-> (? IsRobotClosetoGreenCube
    #          MoveToGreenCube)
    #       GraspGreenCube)
    root = FallbackNode('root')
    is_green_cube_grasped = IsObjectGrasped('IsGreenCubeGrasped', green_cube_id, vrep)
    root.AddChild(is_green_cube_grasped)
    root.AddChild(grasp_cube_sequence)

    # draw_thread = threading.Thread(target=new_draw_tree, args=(root,))
    # draw_thread.start()
    while True:
        root.Execute(None)
        time.sleep(1)

if __name__ == "__main__":
    AchieveGoal()