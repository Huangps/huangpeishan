class NodeStatus:
    Success, Failure, Running, Idle, Halted = range(5)

class NodeColor:
    Gray,Red,Green,Black = range(4)


